import React from 'react';

function NameList(props) {

    return(
        <div className = "input">
            {props.names}
        </div>
    );
}

export default NameList