import React from 'react';

function Add(props) {
  return (
        <button className="button" onClick={props.clicked} id="add">Add</button>
  );
}

export default Add;
